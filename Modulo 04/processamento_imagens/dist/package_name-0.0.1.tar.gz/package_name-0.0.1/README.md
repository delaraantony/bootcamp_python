# image_processing

Description.
The package image_processing is used to:
    Processing:
        - Histrograms Matching
        - Structural similarity
        - Resize Image
    Utils: 
        - Road image
        - Save image
        - Plot image
        - Plot result
        - Plot histogram

## Instalatation
Use the package manager [pip](https://pypi.pypa.io/en/stable/) to install package_name

'''bash
pip install package_name
'''

## Usage

'''python
from package.name.module1_name import file1_name
file1_name.my_function()
'''

## Author
Antony

## License
[MIT](https://chooselicense.com/licenses/mit/)